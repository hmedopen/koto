package com.koto.app.ui.screens.cards

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
internal fun FlashcardStudyScreen(deck: FlashcardDeck, state: FlashcardState, update: (FlashcardState) -> Unit) {
    if (state.complete) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp).testTag("study_complete"),
            verticalArrangement = Arrangement.spacedBy(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(20.dp))
            DeckBadge(deck)
            Text("Deck complete", color = CardsColors.Cream, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("You reviewed ${state.order.size} cards in ${deck.title}.", color = CardsColors.Muted, textAlign = TextAlign.Center)
            DeckStats(state.counts(deck))
            CardsButton("Practice again", { update(state.start(deck)) }, Modifier.fillMaxWidth().testTag("practice_again"))
            CardsButton("Back to deck", { update(state.back()) }, Modifier.fillMaxWidth().testTag("back_to_deck"),
                background = CardsColors.Surface, ink = CardsColors.Cream)
        }
        return
    }
    val card = deck.cards.firstOrNull { it.id == state.currentId } ?: return
    BoxWithConstraints(Modifier.fillMaxSize()) {
    val scrollWholeScreen = maxHeight < 360.dp || LocalDensity.current.fontScale > 1.5f
    Column(Modifier.fillMaxSize().let { if (scrollWholeScreen) it.verticalScroll(rememberScrollState()) else it }
        .padding(20.dp).testTag("flashcard_study"), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CardsButton("‹  Deck", { update(state.back()) }, Modifier.testTag("cards_back"), background = CardsColors.Surface, ink = CardsColors.Cream)
            Text("${state.index + 1} / ${state.order.size}", color = CardsColors.Muted, fontSize = 14.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
        }
        LinearProgressIndicator(progress = { state.index.toFloat() / state.order.size }, modifier = Modifier.fillMaxWidth(),
            color = deck.accent, trackColor = CardsColors.Surface)
        Column(if (scrollWholeScreen) Modifier else Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(deck.title, color = CardsColors.Muted, fontSize = 14.sp)
            key(card.id) {
                StudyCard(card, deck, state, { update(state.flip()) })
            }
        }
        Text(if (state.revealed) "How well did you remember?" else "Reveal the answer to rate this card",
            color = CardsColors.Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        ResponseBar(state.revealed) { rating -> update(state.rate(card.id, rating)) }
    }
    }
}

@Composable
private fun StudyCard(card: Flashcard, deck: FlashcardDeck, state: FlashcardState, flip: () -> Unit) {
    val rotation by animateFloatAsState(if (state.revealed) 180f else 0f, tween(260), label = "Flashcard flip")
    val backVisible = rotation > 90f
    val japaneseVisible = state.japaneseFirst != backVisible
    Column(Modifier.fillMaxWidth().heightIn(min = 280.dp)
        .graphicsLayer { rotationY = rotation; cameraDistance = 12 * density }
        .clip(RoundedCornerShape(16.dp)).background(CardsColors.Surface)
        .border(1.dp, deck.accent.copy(alpha = .4f), RoundedCornerShape(16.dp))
        .clickable(role = Role.Button, onClickLabel = "Flip flashcard", onClick = flip)
        .testTag("study_card").semantics {
            stateDescription = if (state.revealed) "Answer revealed" else "Question"
        }.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Column(Modifier.fillMaxWidth().graphicsLayer { rotationY = if (backVisible) 180f else 0f },
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(22.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(if (japaneseVisible) "日本語" else "ENGLISH", color = deck.accent, fontSize = 11.sp)
                Text("FLIP ↻", color = CardsColors.Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(12.dp))
            Text(if (japaneseVisible) card.japanese else card.english, color = CardsColors.Cream,
                fontSize = if (japaneseVisible) 34.sp else 28.sp, lineHeight = 44.sp,
                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.testTag("card_word"))
            if (japaneseVisible && state.showRomaji) Text(card.romaji, color = deck.accent, fontSize = 17.sp,
                textAlign = TextAlign.Center, modifier = Modifier.testTag("card_romaji"))
            Text(if (backVisible) "Tap to see the front" else "Tap to reveal", color = CardsColors.Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ResponseBar(enabled: Boolean, rate: (CardRating) -> Unit) {
    val largeText = LocalDensity.current.fontScale > 1.3f
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val groups = CardRating.entries.chunked(if (maxWidth < 300.dp || largeText) 2 else 4)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            groups.forEach { group ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    group.forEach { rating ->
                        val (background, ink) = when (rating) {
                            CardRating.Again -> Color(0xFF3C2028) to CardsColors.Coral
                            CardRating.Hard -> Color(0xFF393020) to CardsColors.Yellow
                            CardRating.Good -> Color(0xFF183A2D) to CardsColors.Green
                            CardRating.Easy -> CardsColors.Cream to CardsColors.Background
                        }
                        CardsButton(rating.name, { rate(rating) }, Modifier.weight(1f).testTag("rate_${rating.name.lowercase()}"),
                            background = background, ink = ink, enabled = enabled)
                    }
                }
            }
        }
    }
}
