package com.koto.app.ui.screens.cards

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

@Composable
internal fun DeckDetailScreen(deck: FlashcardDeck, state: FlashcardState, update: (FlashcardState) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().testTag("deck_detail"), contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            CardsButton("‹  All decks", { update(state.back()) }, Modifier.testTag("cards_back"),
                background = CardsColors.Surface, ink = CardsColors.Cream)
        }
        item {
            CardsPanel(Modifier.fillMaxWidth()) {
                DeckBadge(deck)
                Text(deck.title, color = CardsColors.Cream, fontSize = 26.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold)
                Text(deck.description, color = CardsColors.Muted, fontSize = 14.sp)
                Text("${deck.cards.size} cards · ${practiceLabel(state.practiced[deck.id])}", color = deck.accent, fontSize = 12.sp)
            }
        }
        item { DeckStats(state.counts(deck)) }
        item {
            CardsPanel(Modifier.fillMaxWidth()) {
                OptionSwitch("Show Romaji", "romaji_toggle", state.showRomaji) { update(state.copy(showRomaji = it)) }
                OptionSwitch("Shuffle", "shuffle_toggle", state.shuffle) { update(state.copy(shuffle = it)) }
                Text("START SIDE", color = CardsColors.Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                Row(Modifier.fillMaxWidth().selectableGroup(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(true to "Japanese First", false to "English First").forEach { (japanese, label) ->
                        val selected = state.japaneseFirst == japanese
                        CardsButton(label, { update(state.copy(japaneseFirst = japanese)) },
                            Modifier.weight(1f).testTag(if (japanese) "japanese_first" else "english_first"),
                            background = if (selected) CardsColors.Cream else CardsColors.Background,
                            ink = if (selected) CardsColors.Background else CardsColors.Muted, isSelected = selected)
                    }
                }
            }
        }
        item {
            CardsButton("Start Flashcards", { update(state.start(deck)) }, Modifier.fillMaxWidth().testTag("start_flashcards"))
        }
        item {
            Text("IN THIS DECK  ·  ${deck.cards.size}", color = CardsColors.Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
        }
        items(deck.cards, key = { it.id }) { card ->
            CardsPanel(Modifier.fillMaxWidth().testTag("preview_${card.id}")) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(card.japanese, color = CardsColors.Cream, fontSize = 21.sp)
                        if (state.showRomaji) Text(card.romaji, color = deck.accent, fontSize = 12.sp)
                        Text(card.english, color = CardsColors.Muted, fontSize = 13.sp)
                    }
                    MarkButton("star", card.id in state.favorites, "Favorite ${card.english}", "favorite_${card.id}") {
                        update(state.favorite(card.id))
                    }
                }
            }
        }
    }
}

@Composable
internal fun DeckStats(counts: DeckCounts) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(Triple("NEW", counts.new, CardsColors.Cream), Triple("WEAK", counts.weak, CardsColors.Coral),
            Triple("MASTERED", counts.mastered, CardsColors.Green)).forEach { (label, count, ink) ->
            CardsPanel(Modifier.weight(1f).testTag("stat_${label.lowercase()}").semantics(mergeDescendants = true) {}) {
                Text("$count", color = ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(label, color = CardsColors.Muted, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun OptionSwitch(label: String, tag: String, checked: Boolean, change: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag(tag)
        .toggleable(checked, role = Role.Switch, onValueChange = change), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = CardsColors.Cream, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = null, colors = SwitchDefaults.colors(
            checkedTrackColor = CardsColors.Green, checkedThumbColor = CardsColors.Background,
            checkedBorderColor = CardsColors.Green, uncheckedTrackColor = CardsColors.Background,
            uncheckedThumbColor = CardsColors.Muted, uncheckedBorderColor = CardsColors.Edge))
    }
}

private fun practiceLabel(timestamp: Long?): String = if (timestamp == null) "Not practiced yet" else
    "Last practiced ${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(timestamp))}"
