package com.koto.app.ui.screens.cards

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CardsScreen() {
    val context = LocalContext.current
    val decks = remember(context) { loadFlashcardDecks(context) }
    var state by rememberSaveable(stateSaver = FlashcardState.Saver) { mutableStateOf(FlashcardState()) }
    val deck = decks.find { it.id == state.deckId }
    BackHandler(enabled = deck != null) { state = state.back() }
    Box(Modifier.fillMaxSize().background(CardsColors.Background).testTag("screen_cards")) {
        when {
            deck == null -> CategoryGrid(decks, state, { state = state.open(it) }, { state = state.pin(it) })
            state.studying -> FlashcardStudyScreen(deck, state, { state = it })
            else -> DeckDetailScreen(deck, state, { state = it })
        }
    }
}

@Composable
private fun CategoryGrid(decks: List<FlashcardDeck>, state: FlashcardState,
    onOpen: (FlashcardDeck) -> Unit, onPin: (String) -> Unit) {
    val sorted = decks.sortedByDescending { it.id in state.pinned }
    LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxSize().testTag("cards_grid"),
        contentPadding = PaddingValues(20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item(span = { GridItemSpan(2) }) {
            Column(Modifier.padding(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("単語  /  VOCABULARY", color = CardsColors.Coral, fontSize = 11.sp, letterSpacing = 2.sp)
                Text("A little practice.\nA world of words.", color = CardsColors.Cream, fontSize = 27.sp,
                    lineHeight = 35.sp, fontWeight = FontWeight.Bold)
                Text("${decks.size} decks · ${decks.sumOf { it.cards.size }} everyday words", color = CardsColors.Muted, fontSize = 13.sp)
            }
        }
        items(sorted, key = { it.id }) { deck ->
            val counts = state.counts(deck)
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CardsColors.Surface)
                .clickable(role = Role.Button, onClickLabel = "Open ${deck.title}") { onOpen(deck) }
                .testTag("deck_${deck.id}").padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    DeckBadge(deck)
                    MarkButton("bookmark", deck.id in state.pinned, "Pin ${deck.title}", "pin_${deck.id}") { onPin(deck.id) }
                }
                Text(deck.title, color = CardsColors.Cream, fontSize = 16.sp, lineHeight = 23.sp,
                    fontWeight = FontWeight.Bold, modifier = Modifier.heightIn(min = 46.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TileCount(deck.cards.size, "Cards", CardsColors.Muted, Modifier.weight(1f))
                    TileCount(counts.weak, "Weak", CardsColors.Coral, Modifier.weight(1f))
                    TileCount(counts.mastered, "Mastered", CardsColors.Green, Modifier.weight(1.5f))
                }
            }
        }
    }
}

@Composable
private fun TileCount(count: Int, label: String, color: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    Column(modifier) {
        Text("$count", color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(label, color = CardsColors.Muted, fontSize = 9.sp)
    }
}
